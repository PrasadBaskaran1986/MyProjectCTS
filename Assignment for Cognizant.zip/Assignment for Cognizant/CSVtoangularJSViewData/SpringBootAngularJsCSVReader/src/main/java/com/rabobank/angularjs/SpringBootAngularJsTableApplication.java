package com.rabobank.angularjs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootAngularJsTableApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootAngularJsTableApplication.class, args);
	}
}
