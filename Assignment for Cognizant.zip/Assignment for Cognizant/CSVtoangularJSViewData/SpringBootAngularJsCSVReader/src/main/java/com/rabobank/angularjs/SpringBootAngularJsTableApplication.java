package com.rabobank.angularjs;

import java.io.File;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;


@SpringBootApplication
public class SpringBootAngularJsTableApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootAngularJsTableApplication.class, args);
	}
}
