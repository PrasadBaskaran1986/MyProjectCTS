package com.rabobank.validator;

import java.util.HashMap;
import java.util.Map;

import org.springframework.validation.Errors;
import org.springframework.validation.Validator;

import com.rabobank.angularjs.model.Records;

public class RecordsValidator implements Validator {

	public Map<String, String> errorMap = new HashMap<String, String>();
	double startBalance = 0;
	double mutuation = 0;
	double endBalance = 0;

	public boolean supports(Class clazz) {
		return Records.class.isAssignableFrom(clazz);
	}

	public void validate(Object target, Errors errors) {

		Records record = (Records) target;
		startBalance = record.getStartBalance().toString().equalsIgnoreCase("Start Balance") ? 0
				: Double.parseDouble(record.getStartBalance().toString());
		mutuation = record.getMutation().toString().equalsIgnoreCase("Mutation") ? 0
				: Double.parseDouble(record.getMutation().toString());
		endBalance = record.getEndBalance().toString().equalsIgnoreCase("End Balance") ? 0
				: Double.parseDouble(record.getEndBalance().toString());

		if (record.getReference() == null)
			errorMap.put("reference", "getReference is null for Account Number        " + record.getAccountNumber());
		if (record.getAccountNumber() == null)
			errorMap.put("accountNumber",
					"accountNumber is null for Account Number        " + record.getAccountNumber());
		if (record.getDescription() == null)
			errorMap.put("description", "description is null for Account Number        " + record.getAccountNumber());
		if (record.getStartBalance() == null)
			errorMap.put("startBalance", "startBalance is 0 for Account Number        " + record.getAccountNumber());
		if (record.getMutation() == null)
			errorMap.put("mutation", "mutation is 0 for Account Number        " + record.getAccountNumber());
		if (record.getEndBalance() == null)
			errorMap.put("endBalance", "endBalance is 0 for Account Number        " + record.getAccountNumber());
		if (startBalance < 0)
			errorMap.put("startBalance",
					"startBalance is less than 0 for Account Number        " + record.getAccountNumber());
		if (mutuation < 0)
			errorMap.put("mutation", "mutation is less than 0 for Account Number        " + record.getAccountNumber());
		if (endBalance < 0)
			errorMap.put("endBalance",
					"endBalance is less than 0 for Account Number        " + record.getAccountNumber());
	}

}
