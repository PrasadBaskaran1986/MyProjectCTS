package com.rabobank.angularjs.controller;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;
import java.util.stream.Collectors;

import javax.annotation.PostConstruct;

import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.rabobank.angularjs.model.Records;
import com.rabobank.angularjs.model.Records1;
import com.rabobank.validator.RecordsValidator;


@RestController
@RequestMapping("/api/customer")
public class RestAPIs {
	
	String CSVFilepath="C:\\Cognizant\\FinalSource\\SpringBootAngularJsCSVReader\\src\\main\\resources\\records.csv";
	Map<Long, Records1> recStores = new HashMap<Long, Records1>();
	Map<Long, Records1> errorrecStores = new HashMap<Long, Records1>();
	public static final String delimiter = ",";
	BindingResult result =null;
	RecordsValidator validator =  new RecordsValidator();
	
	@PostConstruct
    public void initIt() throws Exception {

		Scanner scanner = new Scanner(new File(CSVFilepath));
		Scanner dataScanner = null;
		int index = 0;
		List<Records> recordList = new ArrayList<>();
		List<Records> errorrecordList = new ArrayList<>();
		
		while (scanner.hasNextLine()) {
			dataScanner = new Scanner(scanner.nextLine());
			dataScanner.useDelimiter(",");
			Records rec = new Records();

			while (dataScanner.hasNext()) {
				String data = dataScanner.next();
				if (index == 0)
					rec.setReference(data);
				else if (index == 1)
					rec.setAccountNumber(data);
				else if (index == 2)
					rec.setDescription(data);
				else if (index == 3)
					rec.setStartBalance(data);
				else if (index == 4)
					rec.setMutation(data);
				else if (index == 5)
					rec.setEndBalance(data);
				else
					System.out.println("invalid data::" + data);
				index++;
			}
			System.out.println("*************************CSV Data Start***********************************************");
			System.out.println("getReference                         "+rec.getReference());
			System.out.println("getAccountNumber                     "+rec.getAccountNumber());
			System.out.println("getDescription                       "+rec.getDescription());
			System.out.println("getStartBalance                      "+rec.getStartBalance());
			System.out.println("getMutation                          "+rec.getMutation());
			System.out.println("getEndBalance                        "+rec.getEndBalance());
			System.out.println("*************************CSV Data End***********************************************");
			
			//Validation code
		    validator.validate(rec, result);
		     
		    //Check validation errors
		    System.out.println("Error Report**********************************************Start");
		    if(validator.errorMap.size()>0){
		    	validator.errorMap.forEach((K,V)-> System.out.println(K+"           Error               "+V));
		    	errorrecordList.add(rec);
		    }
		    System.out.println("Error Report**********************************************End");
			index = 0;
			recordList.add(rec);
		} 
		scanner.close();

	for(int i=1;i<recordList.size();i++)
		recStores.put(Long.valueOf(i), new Records1(recordList.get(i).getReference(), recordList.get(i).getAccountNumber(), 
		recordList.get(i).getDescription(),recordList.get(i).getStartBalance(), recordList.get(i).getMutation(), recordList.get(i).getEndBalance()));
	
	
	for(int i=1;i<errorrecordList.size();i++)
		errorrecStores.put(Long.valueOf(i), new Records1(recordList.get(i).getReference(), recordList.get(i).getAccountNumber(), 
		recordList.get(i).getDescription(),recordList.get(i).getStartBalance(), recordList.get(i).getMutation(), recordList.get(i).getEndBalance()));
	}
	
	 
	@GetMapping(value = "/all")
	public List<Records1> getResource() {
		List<Records1> recordList = recStores.entrySet().stream()
		        .map(entry -> entry.getValue())
		        .collect(Collectors.toList());
		return recordList;
	}
	
	@GetMapping(value = "/error")
	public List<Records1> geterror() {
		List<Records1> errorrecordList = errorrecStores.entrySet().stream()
		        .map(entry -> entry.getValue())
		        .collect(Collectors.toList());
		return errorrecordList;
	}
}
