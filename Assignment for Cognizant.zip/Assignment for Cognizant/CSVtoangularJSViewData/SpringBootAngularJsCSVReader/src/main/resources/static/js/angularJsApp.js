var app = angular.module('app', []);

//#######################
//JSA CONTROLLER
//#######################

app.controller('jsaController', function($scope, $http, $location) {
	$scope.listCustomers = [];
	
	// $scope.getAllCustomer = 
	function getRaboBankRecords(){
		// get URL
		var url = $location.absUrl() + "api/customer/all";
		
		// do getting
		$http.get(url).then(function (response) {
			$scope.getDivAvailable = true;
			$scope.listCustomers = response.data;
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " +  response.statusText;
		});
	}
	
	getRaboBankRecords();
});


var app = angular.module('app1', []);

//#######################
//JSA CONTROLLER
//#######################

app.controller('jsaController1', function($scope, $http, $location) {
	$scope.listCustomers = [];
	
	// $scope.getAllCustomer = 
	function getRaboBankerrorRecords(){
		// get URL
		var url = $location.absUrl() + "api/customer/error";
		
		// do getting
		$http.get(url).then(function (response) {
			$scope.getDivAvailable = true;
			$scope.listerrorrecords = response.data;
		}, function error(response) {
			$scope.postResultMessage = "Error Status: " +  response.statusText;
		});
	}
	
	getRaboBankerrorRecords();
});