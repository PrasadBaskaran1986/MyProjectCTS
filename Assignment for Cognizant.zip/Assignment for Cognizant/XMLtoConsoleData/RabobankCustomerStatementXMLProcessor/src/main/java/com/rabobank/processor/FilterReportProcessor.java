package com.rabobank.processor;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.validation.BindingResult;

import com.rabobank.model.Records;
import com.rabobank.validator.RecordsValidator;

//run before writing
public class FilterReportProcessor implements ItemProcessor<Records, Records> {
	
	BindingResult result =null;
	RecordsValidator validator =  new RecordsValidator();
	Records record =  null;
	int i=1;
	@Override
	public Records process(Records item) throws Exception {
//		System.out.println("*************************XML Data Start***********************************************");
//		System.out.println("XML item                      "+i);
//		System.out.println("getReference                         "+item.getReference());
//		System.out.println("getAccountNumber                     "+item.getAccountNumber());
//		System.out.println("getDescription                       "+item.getDescription());
//		System.out.println("getStartBalance                      "+item.getStartBalance());
//		System.out.println("getMutation                          "+item.getMutation());
//		System.out.println("getEndBalance                        "+item.getEndBalance());
//		System.out.println("*************************XML Data End***********************************************");
		i++;
		
		//Validation code
	    validator.validate(item, result);
	     
	    //Check validation errors
	    System.out.println("Error Report**********************************************Start");
	    if(validator.errorMap.size()>0)
	    	validator.errorMap.forEach((K,V)-> System.out.println(K+"           Error               "+V));
	    System.out.println("Error Report**********************************************End");
	    
		return item;
	}
}