package com.example.schedulerdemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

public class CommonConstants {

	public static final String PROPERTY_FILEPATH = "D:\\TradeTools\\Workspace\\SchedulerCSVDroolsWriter\\Scheduler-Rest-Demo\\src\\main\\resources\\application.properties";

	// Duty Rule parameters
	public static final String DUTYRULE_CSVFILENAME = "DutyRules.csv";
	public static final String DUTYRULE_CSVFILEPATH = "D://TradeTools//DatatoCSV//DutyRule//"
			+ DUTYRULE_CSVFILENAME;
	public static String DUTYRULE_DROOLSFILENAME = "dutyrule.drl";
	public static final String DUTYRULE_DROOLSFILEPATH = "D://TradeTools//DatatoDrools//DutyRule//"
			+ DUTYRULE_DROOLSFILENAME;
	public static final String DUTYRULE_QUERY_CHECKPROCESSFLAG = "select PROCESSED_FLG from DUTY_RULES";
	public static final String DUTYRULE_TABLENAME = "DUTY_RULES";
	public static final String DUTYRULE_PARAMETERS = loadPropertyFile().getProperty("SHIP_KEY_ID") + ","
			+ loadPropertyFile().getProperty("ACTIVATION_GRP") + "," + loadPropertyFile().getProperty("CREATE_TMSTP")
			+ "," + loadPropertyFile().getProperty("DEST_CITY_NM") + ","
			+ loadPropertyFile().getProperty("DEST_COUNTRY_CD") + "," + loadPropertyFile().getProperty("DEST_COUNTY_NM")
			+ "," + loadPropertyFile().getProperty("DEST_LOCALE_TYPE_CD") + ","
			+ loadPropertyFile().getProperty("DEST_POSTAL_CD") + "," + loadPropertyFile().getProperty("DUTY_RULE_ID")
			+ "," + loadPropertyFile().getProperty("EFFECTIVE_DT") + ","
			+ loadPropertyFile().getProperty("EXPIRATION_DT") + ","
			+ loadPropertyFile().getProperty("IN_DEST_COUNTRY_CD") + ","
			+ loadPropertyFile().getProperty("IN_DEST_STATE_PROV_CD") + ","
			+ loadPropertyFile().getProperty("IN_ORGN_COUNTRY_CD") + ","
			+ loadPropertyFile().getProperty("MAX_CUST_AMT") + "," + loadPropertyFile().getProperty("MFR_COUNTRY_CD")
			+ "," + loadPropertyFile().getProperty("MIN_CUST_AMT") + ","
			+ loadPropertyFile().getProperty("NOTIN_DEST_COUNTRY_CD") + ","
			+ loadPropertyFile().getProperty("NOT_IN_DEST_STATE_PROV_CD") + ","
			+ loadPropertyFile().getProperty("NOT_IN_ORIGIN_COUNTRY_CD") + ","
			+ loadPropertyFile().getProperty("ORGN_STATE_PROV_CD") + ","
			+ loadPropertyFile().getProperty("ORGN_COUNTRY_CD") + "," + loadPropertyFile().getProperty("PRIORITY_NBR")
			+ "," + loadPropertyFile().getProperty("PROCESSED_FLG") + "," + loadPropertyFile().getProperty("RULE_NM")
			+ "," + loadPropertyFile().getProperty("SHIP_CRIT_ID") + ","
			+ loadPropertyFile().getProperty("TARIFF_SHIFT_FLG") + ","
			+ loadPropertyFile().getProperty("TRANSPORT_MODE_CD");
	public static final String DUTYRULE_QUERY = "select " + DUTYRULE_PARAMETERS + " from DUTY_RULES";

	// Tax Rule parameters
	public static final String TAXRULE_QUERY_CHECKPROCESSFLAG = "select PROCESSED_FLG from TAX_RULES";
	public static final String TAXRULE_CSVFILENAME = "TaxRules.csv";
	public static final String TAXRULE_CSVFILEPATH = "D://TradeTools//DatatoCSV//TaxRules//"
			+ TAXRULE_CSVFILENAME;
	public static final String TAXRULE_DROOLSFILENAME = "TaxRules.drl";
	public static String TAXRULE_DROOLSFILEPATH = "D://TradeTools//DatatoDrools//TaxRules//"
			+ TAXRULE_DROOLSFILENAME;
	public static final String TAXRULE_PARAMETERS = loadPropertyFile().getProperty("SHIP_KEY_ID") + ","
			+ loadPropertyFile().getProperty("ACTIVATION_GRP") + "," + loadPropertyFile().getProperty("CREATE_TMSTP")
			+ "," + loadPropertyFile().getProperty("DEST_CITY_NM") + ","
			+ loadPropertyFile().getProperty("DEST_COUNTRY_CD") + "," + loadPropertyFile().getProperty("DEST_COUNTY_NM")
			+ "," + loadPropertyFile().getProperty("DEST_LOCALE_TYPE_CD") + ","
			+ loadPropertyFile().getProperty("DEST_POSTAL_CD") + "," + loadPropertyFile().getProperty("TAX_RULE_ID")
			+ "," + loadPropertyFile().getProperty("EFFECTIVE_DT") + ","
			+ loadPropertyFile().getProperty("EXPIRATION_DT") + ","
			+ loadPropertyFile().getProperty("IN_DEST_COUNTRY_CD") + ","
			+ loadPropertyFile().getProperty("IN_DEST_STATE_PROV_CD") + ","
			+ loadPropertyFile().getProperty("IN_ORGN_COUNTRY_CD") + ","
			+ loadPropertyFile().getProperty("MAX_CUST_AMT") + "," + loadPropertyFile().getProperty("MFR_COUNTRY_CD")
			+ "," + loadPropertyFile().getProperty("MIN_CUST_AMT") + ","
			+ loadPropertyFile().getProperty("NOTIN_DEST_COUNTRY_CD") + ","
			+ loadPropertyFile().getProperty("NOT_IN_DEST_STATE_PROV_CD") + ","
			+ loadPropertyFile().getProperty("NOT_IN_ORIGIN_COUNTRY_CD") + ","
			+ loadPropertyFile().getProperty("ORGN_STATE_PROV_CD") + ","
			+ loadPropertyFile().getProperty("ORGN_COUNTRY_CD") + "," + loadPropertyFile().getProperty("PRIORITY_NBR")
			+ "," + loadPropertyFile().getProperty("PROCESSED_FLG") + "," + loadPropertyFile().getProperty("RULE_NM")
			+ "," + loadPropertyFile().getProperty("SHIP_CRIT_ID") + ","
			+ loadPropertyFile().getProperty("TARIFF_SHIFT_FLG") + ","
			+ loadPropertyFile().getProperty("TRANSPORT_MODE_CD");
	public static final String TAXRULE_QUERY = "select " + TAXRULE_PARAMETERS + " from TAX_RULES";
	public static final String TAXRULE_TABLENAME = "TAX_RULES";

	// Fee Rule parameters
	public static final String FEERULE_CSVFILENAME = "FeeRules.csv";
	public static final String FEERULE_CSVFILEPATH = "D://TradeTools//DatatoCSV//FeeRules//"
			+ FEERULE_CSVFILENAME;
	public static final String FEERULE_DROOLSFILENAME = "FeeRules.drl";
	public static String FEERULE_DROOLSFILEPATH = "D://TradeTools//DatatoDrools//FeeRules//"
			+ FEERULE_DROOLSFILENAME;

	public static final String FEERULE_QUERY_CHECKPROCESSFLAG = "select PROCESSED_FLG from FEE_RULES";
	public static final String FEERULE_PARAMETERS = loadPropertyFile().getProperty("SHIP_KEY_ID") + ","
			+ loadPropertyFile().getProperty("ACTIVATION_GRP") + "," + loadPropertyFile().getProperty("CREATE_TMSTP")
			+ "," + loadPropertyFile().getProperty("DEST_CITY_NM") + ","
			+ loadPropertyFile().getProperty("DEST_COUNTRY_CD") + "," + loadPropertyFile().getProperty("DEST_COUNTY_NM")
			+ "," + loadPropertyFile().getProperty("DEST_LOCALE_TYPE_CD") + ","
			+ loadPropertyFile().getProperty("DEST_POSTAL_CD") + "," + loadPropertyFile().getProperty("FEE_RULE_ID")
			+ "," + loadPropertyFile().getProperty("EFFECTIVE_DT") + ","
			+ loadPropertyFile().getProperty("EXPIRATION_DT") + ","
			+ loadPropertyFile().getProperty("IN_DEST_COUNTRY_CD") + ","
			+ loadPropertyFile().getProperty("IN_DEST_STATE_PROV_CD") + ","
			+ loadPropertyFile().getProperty("IN_ORGN_COUNTRY_CD") + ","
			+ loadPropertyFile().getProperty("MAX_CUST_AMT") + "," + loadPropertyFile().getProperty("MFR_COUNTRY_CD")
			+ "," + loadPropertyFile().getProperty("MIN_CUST_AMT") + ","
			+ loadPropertyFile().getProperty("NOTIN_DEST_COUNTRY_CD") + ","
			+ loadPropertyFile().getProperty("NOT_IN_DEST_STATE_PROV_CD") + ","
			+ loadPropertyFile().getProperty("NOT_IN_ORIGIN_COUNTRY_CD") + ","
			+ loadPropertyFile().getProperty("ORGN_STATE_PROV_CD") + ","
			+ loadPropertyFile().getProperty("ORGN_COUNTRY_CD") + "," + loadPropertyFile().getProperty("PRIORITY_NBR")
			+ "," + loadPropertyFile().getProperty("PROCESSED_FLG") + "," + loadPropertyFile().getProperty("RULE_NM")
			+ "," + loadPropertyFile().getProperty("SHIP_CRIT_ID") + ","
			+ loadPropertyFile().getProperty("TARIFF_SHIFT_FLG") + ","
			+ loadPropertyFile().getProperty("TRANSPORT_MODE_CD");
	public static final String FEERULE_QUERY = "select " + FEERULE_PARAMETERS + " from FEE_RULES";
	public static final String FEERULE_TABLENAME = "FEE_RULES";

	public static Properties loadPropertyFile() {
		InputStream is = null;
		Properties prop = null;
		try {
			prop = new Properties();
			is = new FileInputStream(new File(PROPERTY_FILEPATH));
			prop.load(is);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return prop;
	}

	public static void updateProcessFlag(String tablename) {
		// DUTY_RULES";
		final String DUTYRULE_QUERY_SHIP_KEY_ID = "select SHIP_KEY_ID from " + tablename;
		List<String> shipKeyIDlist = new ArrayList<String>();
		ResultSet rs = null;
		try {
			rs =  OracleDBConnection.getDbCon().query(DUTYRULE_QUERY_SHIP_KEY_ID);
			while (rs.next()) {
				shipKeyIDlist.add(rs.getString("SHIP_KEY_ID"));
				System.out.println("PROCESSED_FLG>>>>>>>>>>>>>>" + shipKeyIDlist);
			}

			for (int i = 0; i < shipKeyIDlist.size(); i++) {
				String sql = "UPDATE " + tablename + " SET PROCESSED_FLG = 'Y' WHERE SHIP_KEY_ID = "
						+ shipKeyIDlist.get(i);
				int updatequery =  OracleDBConnection.getDbCon().update(sql);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	}

	public static void deleteCSVandDroolsFile(String CSVFile, String droolsfile) {
		try {
			File file = new File(CSVFile);
			if (file.exists()) {
				file.delete();
				System.out.println(file + " is deleted");
			} else {
				System.out.println("Delete operation is failed.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		try {
			File file = new File(droolsfile);
			if (file.exists()) {
				file.delete();
				System.out.println(file + " is deleted");
			} else {
				System.out.println("Delete operation is failed.");
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
