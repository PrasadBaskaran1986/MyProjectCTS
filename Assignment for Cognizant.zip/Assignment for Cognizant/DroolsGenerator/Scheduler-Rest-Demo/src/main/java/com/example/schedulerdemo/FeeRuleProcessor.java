package com.example.schedulerdemo;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.csvreader.CsvWriter;
import com.example.schedulerdemo.model.FeeRule;

public class FeeRuleProcessor {
	
	
	public static void processFeeRule(){
		List<String> processflaglist = new ArrayList<String>();
		List<FeeRule> feerulelist = new ArrayList<FeeRule>();
		ResultSet rs = null,rs1 = null;
		try {
			try {
				rs =  OracleDBConnection.getDbCon().query(CommonConstants.FEERULE_QUERY_CHECKPROCESSFLAG);
				while (rs.next()) {
					processflaglist.add(rs.getString("PROCESSED_FLG"));
				}
				if (processflaglist.contains("N")) {
					CommonConstants.deleteCSVandDroolsFile(CommonConstants.FEERULE_CSVFILEPATH, CommonConstants.FEERULE_DROOLSFILEPATH);
					rs1 =  OracleDBConnection.getDbCon().query(CommonConstants.FEERULE_QUERY);
					while (rs1.next()) {
						System.out.println("Data Processing...............");
						long shipKeyId = rs1.getLong("SHIP_KEY_ID");
						String activationGrp = rs1.getString("ACTIVATION_GRP");
						Timestamp createTmstp = rs1.getTimestamp("CREATE_TMSTP");
						String destCityNm = rs1.getString("DEST_CITY_NM");
						String destCountryCd = rs1.getString("DEST_COUNTRY_CD");
						String destCountyNm = rs1.getString("DEST_COUNTY_NM");
						String destLocaleTypeCd = rs1.getString("DEST_LOCALE_TYPE_CD");
						String destPostalCd = rs1.getString("DEST_POSTAL_CD");
						BigDecimal feeRuleId = rs1.getBigDecimal("FEE_RULE_ID");
						Date effectiveDt = rs1.getDate("EFFECTIVE_DT");
						Date expirationDt = rs1.getDate("EXPIRATION_DT");
						String inDestCountryCd = rs1.getString("IN_DEST_COUNTRY_CD");
						String inDestStateProvCd = rs1.getString("IN_DEST_STATE_PROV_CD");
						String inOrgnCountryCd = rs1.getString("IN_ORGN_COUNTRY_CD");
						double maxCustAmt = rs1.getDouble("MAX_CUST_AMT");
						String mfrCountryCd = rs1.getString("MFR_COUNTRY_CD");
						Float minCustAmt = rs1.getFloat("MIN_CUST_AMT");
						String notinDestCountryCd = rs1.getString("NOTIN_DEST_COUNTRY_CD");
						String notInDestStateProvCd = rs1.getString("NOT_IN_DEST_STATE_PROV_CD");
						String notInOriginCountryCd = rs1.getString("NOT_IN_ORIGIN_COUNTRY_CD");
						String orgnStateProvCd = rs1.getString("ORGN_STATE_PROV_CD");
						String orgnCountryCd = rs1.getString("ORGN_COUNTRY_CD");
						double priorityNbr = rs1.getDouble("PRIORITY_NBR");
						String processedFlg = rs1.getString("PROCESSED_FLG");
						BigDecimal ruleNm = rs1.getBigDecimal("RULE_NM");
						double shipCritId = rs1.getDouble("SHIP_CRIT_ID");
						String tariffShiftFlg = rs1.getString("TARIFF_SHIFT_FLG");
						String transportModeCd = rs1.getString("TRANSPORT_MODE_CD");
						
						FeeRule feerule = new FeeRule( shipKeyId, activationGrp, createTmstp, destCityNm, destCountryCd,
								destCountyNm, destLocaleTypeCd, destPostalCd,  effectiveDt,  expirationDt,
								 feeRuleId, inDestCountryCd, inDestStateProvCd, inOrgnCountryCd,
								 maxCustAmt, mfrCountryCd,  minCustAmt, notInDestStateProvCd,
								notInOriginCountryCd, notinDestCountryCd, orgnCountryCd, orgnStateProvCd,
								 priorityNbr, processedFlg,  ruleNm,  shipCritId, tariffShiftFlg,
								transportModeCd);
						feerulelist.add(feerule);
					}
					updateFeeRuleDataCsvFile(feerulelist);
				}else{
					System.out.println("Fee Rule Data Already Processed...............No More Data");
				}

			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally{
				if(rs!=null){
					rs.close();
				}
				if(rs1!=null){
					rs1.close();
				}			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
		}
	}

	private static void updateFeeRuleDataCsvFile(List<FeeRule> feerulelist) {
		boolean alreadyExists = new File(CommonConstants.FEERULE_CSVFILEPATH).exists();
		try {
			// use FileWriter constructor that specifies open for appending
			CsvWriter csvOutput = new CsvWriter(new FileWriter(
					CommonConstants.FEERULE_CSVFILEPATH, true), ',');
			// if the file didn't already exist then we need to write out the
			// header line
			if (!alreadyExists) {
				csvOutput.write("");
				csvOutput.write("RuleSet");
				csvOutput.write("com.edt.VO");
				csvOutput.endRecord();

				csvOutput.write("");
				csvOutput.write("Import");
				csvOutput.write("com.edt.VO.DutyRuleVO, org.drools.core.util.DateUtils");
				csvOutput.endRecord();

				csvOutput.write("");
				csvOutput.write("Notes");
				csvOutput.write("Decision Table for Duty Processing");
				csvOutput.endRecord();

				csvOutput.write("");
				csvOutput.write("Sequential");
				csvOutput.write("FALSE");
				csvOutput.endRecord();

				csvOutput.write("");
				csvOutput.write("NO-LOOP");
				csvOutput.write("TRUE");
				csvOutput.endRecord();

				csvOutput.endRecord();

				csvOutput.write("RuleTable Duty Processing");
				csvOutput.endRecord();

				for (int i = 0; i < 20; i++) {
					csvOutput.write("CONDITION");
				}
				csvOutput.write("ACTIVATION-GROUP");
				csvOutput.write("PRIORITY");
				csvOutput.write("ACTION");
				csvOutput.endRecord();

				csvOutput.write("$f:FeeRuleVO");
				csvOutput.endRecord();

				csvOutput.write("originStateProvinceCode == \"$param\"");
				csvOutput.write("originCountryCode in ($param)");
				csvOutput.write("originCountryCode not in ($param)");
				csvOutput.write("destinationCountryCode == \"$param\"");
				csvOutput.write("destinationCountryCode in ($param)");
				csvOutput.write("destinationStateOrProvinceCode in ($param)");
				csvOutput.write("destinationStateOrProvinceCode not in ($param)");
				csvOutput.write("destinationCounty == \"$param\"");
				csvOutput.write("destinationCity == \"$param\"");
				csvOutput.write("destinationPostalCode == \"$param\"");
				csvOutput.write("destinationLocaleType == \"$param\"");
				csvOutput.write("customsValueCurrencyCode == \"$param\"");
				csvOutput.write("customsValue >= $param");
				csvOutput.write("customsValue < $param");
				csvOutput.write("countryOfManufacture == \"$param\"");
				csvOutput.write("modeOfTransportation matches \"$param\"");
				csvOutput.write("shipmentCriteriaID == \"$param\"");
				csvOutput.write("tariffShift == \"$param\"");
				csvOutput.write("effectiveDate >= DateUtils.parseDate(\"$param\")");
				csvOutput.write("expirationDate <= DateUtils.parseDate(\"$param\")");
				csvOutput.write("");
				csvOutput.write("");
				csvOutput.write("$f.setShipmentKey(\"$param\"); ");
				csvOutput.endRecord();

				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("OriginStateProvinceCode"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("originCountryCode"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("originCountryCode"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("destinationCountryCode"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("destinationCountryCode"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("DestinationStateOrProvinceCode"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("DestinationStateOrProvinceCode"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("DestinationCounty"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("DestinationCity"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("DestinationPostalCode"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("DestinationLocaleType"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("CustomsValueCurrencyCode"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("MinCustomsValue"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("MaxCustomsValue"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("CountryOfManufacture"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("ModeOfTransportation"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("ShipmentCriteriaID"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("TARIFFSHIFT"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("EffectiveDate"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("ExpirationDate"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("ACTIVATION-GROUP"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("PRIORITY"));
				csvOutput.write(CommonConstants.loadPropertyFile().getProperty("ShipmentKey"));
				csvOutput.endRecord();
			}
			// else assume that the file already has the correct header line
			// write out a few records

			for (int i = 0; i < feerulelist.size(); i++) {
				
				csvOutput.write(String.valueOf(feerulelist.get(i).getFeeRuleId()));
				csvOutput.write(feerulelist.get(i).getActivationGrp() != null ? feerulelist.get(i).getActivationGrp(): "");
				//csvOutput.write(feerulelist.get(i).getCreateTmstp() != null ? feerulelist.get(i).getCreateTmstp(): false);
				csvOutput.write(feerulelist.get(i).getDestCityNm());
				csvOutput.write(feerulelist.get(i).getDestCountryCd());
				csvOutput.write(feerulelist.get(i).getDestCountyNm());
				csvOutput.write(feerulelist.get(i).getDestLocaleTypeCd());
				csvOutput.write(feerulelist.get(i).getDestPostalCd());
				csvOutput.write(feerulelist.get(i).getEffectiveDt().toString());
				csvOutput.write(feerulelist.get(i).getExpirationDt().toString());
				csvOutput.write(feerulelist.get(i).getInDestCountryCd().toString());
				csvOutput.write(feerulelist.get(i).getInDestStateProvCd().toString());
				csvOutput.write(feerulelist.get(i).getInOrgnCountryCd().toString());
				csvOutput.write(String.valueOf(feerulelist.get(i).getMaxCustAmt()));
				csvOutput.write(feerulelist.get(i).getMfrCountryCd());
				csvOutput.write(String.valueOf(feerulelist.get(i).getMinCustAmt()));
				csvOutput.write(feerulelist.get(i).getNotinDestCountryCd());
				csvOutput.write(feerulelist.get(i).getOrgnCountryCd());
				csvOutput.write(feerulelist.get(i).getOrgnStateProvCd());
				csvOutput.write(String.valueOf(feerulelist.get(i).getPriorityNbr()));
				csvOutput.write(String.valueOf(feerulelist.get(i).getRuleNm()));
				csvOutput.write(String.valueOf(feerulelist.get(i).getShipCritId()));
				csvOutput.write(Long.toString(feerulelist.get(i).getShipKeyId()));
//				csvOutput.write(feerulelist.get(i).getTariffShiftFlg());
//				csvOutput.write(feerulelist.get(i).getTransportModeCd());
				csvOutput.endRecord();
			}
			System.out.println("Fee Rule CSV file was created successfully !!!");
			csvOutput.close();
			DroolsGenerator.CSVtodroolsGenerator(CommonConstants.FEERULE_CSVFILEPATH,CommonConstants.FEERULE_DROOLSFILEPATH);
			CommonConstants.updateProcessFlag(CommonConstants.FEERULE_TABLENAME);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}
}
