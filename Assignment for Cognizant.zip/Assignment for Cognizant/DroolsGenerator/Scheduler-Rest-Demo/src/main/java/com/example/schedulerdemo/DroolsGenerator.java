package com.example.schedulerdemo;

import java.io.BufferedWriter;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;

import org.drools.decisiontable.InputType;
import org.drools.decisiontable.SpreadsheetCompiler;
import org.kie.internal.builder.KnowledgeBuilder;
import org.kie.internal.builder.KnowledgeBuilderFactory;

/*******************************************************************************
 * Copyright: CopyRight 2007 FedEx Corporation All Rights Reserved
 *
 * Application Name: Trade Tools 
 * File Name: DutyRuleGenerator.java 
 * 
 * $Source: edt-drools/com.edt.drools/DutyRuleGenerator.java 
 * $Revision: 1.0
 * $Author: 5234639 
 * $Date: 02/20/2018
 ******************************************************************************/

/**
 * This class will create a drl file from excel sheet and then execute the
 * rules.
 */
public class DroolsGenerator {
	
	public static void CSVtodroolsGenerator(String CSVFilepath,String droolsfilepath){

		// Create knowledge builder
		final KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();

		// Create drl file from excel sheet
		InputStream is = null;
		try {
			//*********Duty*********
			//is = new FileInputStream("D:\\Trade Tools - Estimated Duties and Taxes\\DatatoCSV\\Duty Rule\\DutyRules.csv");
			is = new FileInputStream(CSVFilepath);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		// Create compiler class instance
		SpreadsheetCompiler sc = new SpreadsheetCompiler();

		// Compile the excel to generate the (.drl) file
		StringBuffer drl = new StringBuffer(sc.compile(is, InputType.CSV));

		// Insert dialect value into drl file
		
		//*********Duty & Tax & Fee*********
		drl.insert(drl.indexOf("DateUtils")+11, "\n"+"dialect \"mvel\"" + "\n");
				
		// Check the generated drl file
		System.out.println("Generate DRL file is shown below: ");
		System.out.println(drl);

		// writing string into a drl file
		try {
			
			//*********Fee*********
			BufferedWriter out = new BufferedWriter(
					new FileWriter(droolsfilepath));
			out.write(drl.toString());
			out.close();
		} catch (IOException e) {
			System.out.println("Exception");
		}
		// Wait before using the drl file in the next section.
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// End creation of drl file from excel sheet
	
	}
	
	public static final void main(final String[] args) {
		// Create knowledge builder
		final KnowledgeBuilder kbuilder = KnowledgeBuilderFactory.newKnowledgeBuilder();

		// Create drl file from excel sheet
		InputStream is = null;
		try {
			//*********Duty*********
			is = new FileInputStream("D:\\Trade Tools - Estimated Duties and Taxes\\DatatoCSV\\Duty Rule\\DutyRules.csv");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		// Create compiler class instance
		SpreadsheetCompiler sc = new SpreadsheetCompiler();

		// Compile the excel to generate the (.drl) file
		StringBuffer drl = new StringBuffer(sc.compile(is, InputType.CSV));

		// Insert dialect value into drl file
		
		//*********Duty & Tax & Fee*********
		drl.insert(drl.indexOf("DateUtils")+11, "\n"+"dialect \"mvel\"" + "\n");
				
		// Check the generated drl file
		System.out.println("Generate DRL file is shown below: ");
		System.out.println(drl);

		// writing string into a drl file
		try {
			
			//*********Fee*********
			BufferedWriter out = new BufferedWriter(
					new FileWriter("D:\\Trade Tools - Estimated Duties and Taxes\\DatatoDrools\\Duty Rule\\dutyrule.drl"));
			out.write(drl.toString());
			out.close();
		} catch (IOException e) {
			System.out.println("Exception");
		}
		// Wait before using the drl file in the next section.
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		// End creation of drl file from excel sheet
	}
}
