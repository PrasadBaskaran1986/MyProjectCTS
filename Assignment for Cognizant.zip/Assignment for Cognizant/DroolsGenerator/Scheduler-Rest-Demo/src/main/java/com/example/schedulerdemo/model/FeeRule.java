package com.example.schedulerdemo.model;

import java.io.Serializable;
import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;
import java.sql.Timestamp;


/**
 * The persistent class for the FEE_RULES database table.
 * 
 */
@Entity
@Table(name="FEE_RULES")
@NamedQuery(name="FeeRule.findAll", query="SELECT f FROM FeeRule f")
public class FeeRule implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@Column(name="SHIP_KEY_ID")
	private long shipKeyId;

	@Column(name="ACTIVATION_GRP")
	private String activationGrp;

	@Column(name="CREATE_TMSTP")
	private Timestamp createTmstp;

	@Column(name="DEST_CITY_NM")
	private String destCityNm;

	@Column(name="DEST_COUNTRY_CD")
	private String destCountryCd;

	@Column(name="DEST_COUNTY_NM")
	private String destCountyNm;

	@Column(name="DEST_LOCALE_TYPE_CD")
	private String destLocaleTypeCd;

	@Column(name="DEST_POSTAL_CD")
	private String destPostalCd;

	@Temporal(TemporalType.DATE)
	@Column(name="EFFECTIVE_DT")
	private Date effectiveDt;

	@Temporal(TemporalType.DATE)
	@Column(name="EXPIRATION_DT")
	private Date expirationDt;

	@Column(name="FEE_RULE_ID")
	private BigDecimal feeRuleId;

	@Column(name="IN_DEST_COUNTRY_CD")
	private String inDestCountryCd;

	@Column(name="IN_DEST_STATE_PROV_CD")
	private String inDestStateProvCd;

	@Column(name="IN_ORGN_COUNTRY_CD")
	private String inOrgnCountryCd;

	@Column(name="MAX_CUST_AMT")
	private double maxCustAmt;

	@Column(name="MFR_COUNTRY_CD")
	private String mfrCountryCd;

	@Column(name="MIN_CUST_AMT")
	private double minCustAmt;

	@Column(name="NOT_IN_DEST_STATE_PROV_CD")
	private String notInDestStateProvCd;

	@Column(name="NOT_IN_ORIGIN_COUNTRY_CD")
	private String notInOriginCountryCd;

	@Column(name="NOTIN_DEST_COUNTRY_CD")
	private String notinDestCountryCd;

	@Column(name="ORGN_COUNTRY_CD")
	private String orgnCountryCd;

	@Column(name="ORGN_STATE_PROV_CD")
	private String orgnStateProvCd;

	@Column(name="PRIORITY_NBR")
	private double priorityNbr;

	@Column(name="PROCESSED_FLG")
	private String processedFlg;

	@Column(name="RULE_NM")
	private BigDecimal ruleNm;

	@Column(name="SHIP_CRIT_ID")
	private double shipCritId;

	@Column(name="TARIFF_SHIFT_FLG")
	private String tariffShiftFlg;

	@Column(name="TRANSPORT_MODE_CD")
	private String transportModeCd;

	public FeeRule() {
	}

	public long getShipKeyId() {
		return this.shipKeyId;
	}

	public void setShipKeyId(long shipKeyId) {
		this.shipKeyId = shipKeyId;
	}

	public String getActivationGrp() {
		return this.activationGrp;
	}

	public void setActivationGrp(String activationGrp) {
		this.activationGrp = activationGrp;
	}

	public Timestamp getCreateTmstp() {
		return this.createTmstp;
	}

	public void setCreateTmstp(Timestamp createTmstp) {
		this.createTmstp = createTmstp;
	}

	public String getDestCityNm() {
		return this.destCityNm;
	}

	public void setDestCityNm(String destCityNm) {
		this.destCityNm = destCityNm;
	}

	public String getDestCountryCd() {
		return this.destCountryCd;
	}

	public void setDestCountryCd(String destCountryCd) {
		this.destCountryCd = destCountryCd;
	}

	public String getDestCountyNm() {
		return this.destCountyNm;
	}

	public void setDestCountyNm(String destCountyNm) {
		this.destCountyNm = destCountyNm;
	}

	public String getDestLocaleTypeCd() {
		return this.destLocaleTypeCd;
	}

	public void setDestLocaleTypeCd(String destLocaleTypeCd) {
		this.destLocaleTypeCd = destLocaleTypeCd;
	}

	public String getDestPostalCd() {
		return this.destPostalCd;
	}

	public void setDestPostalCd(String destPostalCd) {
		this.destPostalCd = destPostalCd;
	}

	public Date getEffectiveDt() {
		return this.effectiveDt;
	}

	public void setEffectiveDt(Date effectiveDt) {
		this.effectiveDt = effectiveDt;
	}

	public Date getExpirationDt() {
		return this.expirationDt;
	}

	public void setExpirationDt(Date expirationDt) {
		this.expirationDt = expirationDt;
	}

	public BigDecimal getFeeRuleId() {
		return this.feeRuleId;
	}

	public void setFeeRuleId(BigDecimal feeRuleId) {
		this.feeRuleId = feeRuleId;
	}

	public String getInDestCountryCd() {
		return this.inDestCountryCd;
	}

	public void setInDestCountryCd(String inDestCountryCd) {
		this.inDestCountryCd = inDestCountryCd;
	}

	public String getInDestStateProvCd() {
		return this.inDestStateProvCd;
	}

	public void setInDestStateProvCd(String inDestStateProvCd) {
		this.inDestStateProvCd = inDestStateProvCd;
	}

	public String getInOrgnCountryCd() {
		return this.inOrgnCountryCd;
	}

	public void setInOrgnCountryCd(String inOrgnCountryCd) {
		this.inOrgnCountryCd = inOrgnCountryCd;
	}

	public double getMaxCustAmt() {
		return this.maxCustAmt;
	}

	public void setMaxCustAmt(double maxCustAmt) {
		this.maxCustAmt = maxCustAmt;
	}

	public String getMfrCountryCd() {
		return this.mfrCountryCd;
	}

	public void setMfrCountryCd(String mfrCountryCd) {
		this.mfrCountryCd = mfrCountryCd;
	}

	public double getMinCustAmt() {
		return this.minCustAmt;
	}

	public void setMinCustAmt(double minCustAmt) {
		this.minCustAmt = minCustAmt;
	}

	public String getNotInDestStateProvCd() {
		return this.notInDestStateProvCd;
	}

	public void setNotInDestStateProvCd(String notInDestStateProvCd) {
		this.notInDestStateProvCd = notInDestStateProvCd;
	}

	public String getNotInOriginCountryCd() {
		return this.notInOriginCountryCd;
	}

	public void setNotInOriginCountryCd(String notInOriginCountryCd) {
		this.notInOriginCountryCd = notInOriginCountryCd;
	}

	public String getNotinDestCountryCd() {
		return this.notinDestCountryCd;
	}

	public void setNotinDestCountryCd(String notinDestCountryCd) {
		this.notinDestCountryCd = notinDestCountryCd;
	}

	public String getOrgnCountryCd() {
		return this.orgnCountryCd;
	}

	public void setOrgnCountryCd(String orgnCountryCd) {
		this.orgnCountryCd = orgnCountryCd;
	}

	public String getOrgnStateProvCd() {
		return this.orgnStateProvCd;
	}

	public void setOrgnStateProvCd(String orgnStateProvCd) {
		this.orgnStateProvCd = orgnStateProvCd;
	}

	public double getPriorityNbr() {
		return this.priorityNbr;
	}

	public void setPriorityNbr(double priorityNbr) {
		this.priorityNbr = priorityNbr;
	}

	public String getProcessedFlg() {
		return this.processedFlg;
	}

	public void setProcessedFlg(String processedFlg) {
		this.processedFlg = processedFlg;
	}

	public BigDecimal getRuleNm() {
		return this.ruleNm;
	}

	public void setRuleNm(BigDecimal ruleNm) {
		this.ruleNm = ruleNm;
	}

	public double getShipCritId() {
		return this.shipCritId;
	}

	public void setShipCritId(double shipCritId) {
		this.shipCritId = shipCritId;
	}

	public FeeRule(long shipKeyId, String activationGrp, Timestamp createTmstp, String destCityNm, String destCountryCd,
			String destCountyNm, String destLocaleTypeCd, String destPostalCd, Date effectiveDt, Date expirationDt,
			BigDecimal feeRuleId, String inDestCountryCd, String inDestStateProvCd, String inOrgnCountryCd,
			double maxCustAmt, String mfrCountryCd, double minCustAmt, String notInDestStateProvCd,
			String notInOriginCountryCd, String notinDestCountryCd, String orgnCountryCd, String orgnStateProvCd,
			double priorityNbr, String processedFlg, BigDecimal ruleNm, double shipCritId, String tariffShiftFlg,
			String transportModeCd) {
		super();
		this.shipKeyId = shipKeyId;
		this.activationGrp = activationGrp;
		this.createTmstp = createTmstp;
		this.destCityNm = destCityNm;
		this.destCountryCd = destCountryCd;
		this.destCountyNm = destCountyNm;
		this.destLocaleTypeCd = destLocaleTypeCd;
		this.destPostalCd = destPostalCd;
		this.effectiveDt = effectiveDt;
		this.expirationDt = expirationDt;
		this.feeRuleId = feeRuleId;
		this.inDestCountryCd = inDestCountryCd;
		this.inDestStateProvCd = inDestStateProvCd;
		this.inOrgnCountryCd = inOrgnCountryCd;
		this.maxCustAmt = maxCustAmt;
		this.mfrCountryCd = mfrCountryCd;
		this.minCustAmt = minCustAmt;
		this.notInDestStateProvCd = notInDestStateProvCd;
		this.notInOriginCountryCd = notInOriginCountryCd;
		this.notinDestCountryCd = notinDestCountryCd;
		this.orgnCountryCd = orgnCountryCd;
		this.orgnStateProvCd = orgnStateProvCd;
		this.priorityNbr = priorityNbr;
		this.processedFlg = processedFlg;
		this.ruleNm = ruleNm;
		this.shipCritId = shipCritId;
		this.tariffShiftFlg = tariffShiftFlg;
		this.transportModeCd = transportModeCd;
	}

//	public FeeRule(long shipRuleId, String activationgroup, Timestamp createtmstp2, String destCityNm2,
//			String destCountryCd2, String destCountyNm2, String destLocaleTypeCd2, String destPostalCd2,
//			BigDecimal feeRuleId2, Date effectiveDt2, Date expirationDt2, String inDestCountryCd2,
//			String inDestStateProvCd2, String inOrgnCountryCd2, double maxCustAmt2, String mfrCountryCd2,
//			Float minCustAmt2, String notinDestCountryCd2, String notInDestStateProvCd2, String notInOriginCountryCd2,
//			String orgnStateProvCd2, String orgnCountryCd2, double priorityNbr2, String processedflag,
//			BigDecimal rulenm2, double shipcritid2, String tariffshiftflag, String transportmodecd2) {
//		// TODO Auto-generated constructor stub
//	}

	public String getTariffShiftFlg() {
		return this.tariffShiftFlg;
	}

	public void setTariffShiftFlg(String tariffShiftFlg) {
		this.tariffShiftFlg = tariffShiftFlg;
	}

	public String getTransportModeCd() {
		return this.transportModeCd;
	}

	public void setTransportModeCd(String transportModeCd) {
		this.transportModeCd = transportModeCd;
	}

}