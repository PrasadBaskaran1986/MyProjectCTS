package com.example.schedulerdemo;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
 
@RestController
@RequestMapping("/etl")
public class DroolsRestApiController {
 
	String message = "Drools Generated";
    public static final Logger logger = LoggerFactory.getLogger(DroolsRestApiController.class);
 
    // -------------------Generate Drools---------------------------------------------
    @GetMapping(path = "/generateDrools/{type}")
	public String GenerateDrools(@PathVariable String type) throws Exception {
    	System.out.println("type>>>>>>>>>>>>>>>>"+type);
    	if(type.equalsIgnoreCase("DutyRule")){
    		DutyRuleProcessor.processDutyRule();
    		message = "Duty Rule Processed"; 
    	}
    	if(type.equalsIgnoreCase("TaxRule")){
    		TaxRuleProcessor.processTaxRule();
        	message = "Tax Rule Processed";
    	}
    	if(type.equalsIgnoreCase("FeeRule"))
    	{
    		FeeRuleProcessor.processFeeRule();
    		message = "Fee Rule Processed";
    	}else{
    		message = "Wrong input to process DB";
    	}
		return message;
	}
 
}