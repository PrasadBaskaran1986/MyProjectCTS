package com.example.schedulerdemo;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Properties;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.csvreader.CsvWriter;
import com.example.schedulerdemo.model.DutyRule;
import com.example.schedulerdemo.model.TaxRule;
import com.example.schedulerdemo.model.FeeRule;

@Component
public class ScheduledTasks {
	private static final SimpleDateFormat dateFormat = new SimpleDateFormat("HH:mm:ss");
	// 40 seconds
	@Scheduled(cron = "*/40 * * * * *")
	public void cronTimeReport() {
		System.out.println("Process Duty Rule CSV for every 40 seconds");
		DutyRuleProcessor.processDutyRule();
		TaxRuleProcessor.processTaxRule();
		FeeRuleProcessor.processFeeRule();
	}
}
