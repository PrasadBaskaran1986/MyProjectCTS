package com.javatpoint.model;

import java.util.Objects;

import javax.persistence.*;

@Entity
@Table(name = "SBI_RTGS_manager")
public class SBI_RTGS_MANAGER_Archive {

	@Id
	private String id;

	@Column(name = "corpid")
	private String corpid;

	@Column(name = "accountnumber")
	private String accountnumber;

	@Column(name = "IFSCCode")
	private String IFSCCode;

	@Column(name = "IFSCReceiver")
	private String IFSCReceiver;

	@Column(name = "Bankbranch")
	private String Bankbranch;

	@Column(name = "email")
	private String email;

	@Column(name = "phonenumber")
	private String phonenumber;

	@Column(name = "Address1")
	private String Address1;

	@Column(name = "Address2")
	private String Address2;

	@Column(name = "Address3")
	private String Address3;

	@Column(name = "status")
	private String status;

	public synchronized String getId() {
		return id;
	}

	public synchronized void setId(String id) {
		this.id = id;
	}

	public synchronized String getCorpid() {
		return corpid;
	}

	public synchronized void setCorpid(String corpid) {
		this.corpid = corpid;
	}

	public synchronized String getAccountnumber() {
		return accountnumber;
	}

	public synchronized void setAccountnumber(String accountnumber) {
		this.accountnumber = accountnumber;
	}

	public synchronized String getIFSCCode() {
		return IFSCCode;
	}

	public synchronized void setIFSCCode(String iFSCCode) {
		IFSCCode = iFSCCode;
	}

	public synchronized String getIFSCReceiver() {
		return IFSCReceiver;
	}

	public synchronized void setIFSCReceiver(String iFSCReceiver) {
		IFSCReceiver = iFSCReceiver;
	}

	public synchronized String getBankbranch() {
		return Bankbranch;
	}

	public synchronized void setBankbranch(String bankbranch) {
		Bankbranch = bankbranch;
	}

	public synchronized String getEmail() {
		return email;
	}

	public synchronized void setEmail(String email) {
		this.email = email;
	}

	public synchronized String getPhonenumber() {
		return phonenumber;
	}

	public synchronized void setPhonenumber(String phonenumber) {
		this.phonenumber = phonenumber;
	}

	public synchronized String getAddress1() {
		return Address1;
	}

	public synchronized void setAddress1(String address1) {
		Address1 = address1;
	}

	public synchronized String getAddress2() {
		return Address2;
	}

	public synchronized void setAddress2(String address2) {
		Address2 = address2;
	}

	@Override
	public int hashCode() {
		return Objects.hash(Address1, Address2, Address3, Bankbranch, IFSCCode, IFSCReceiver, accountnumber, corpid,
				email, id, phonenumber, status);
	}

	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		SBI_RTGS_MANAGER_Archive other = (SBI_RTGS_MANAGER_Archive) obj;
		return Objects.equals(Address1, other.Address1) && Objects.equals(Address2, other.Address2)
				&& Objects.equals(Address3, other.Address3) && Objects.equals(Bankbranch, other.Bankbranch)
				&& Objects.equals(IFSCCode, other.IFSCCode) && Objects.equals(IFSCReceiver, other.IFSCReceiver)
				&& Objects.equals(accountnumber, other.accountnumber) && Objects.equals(corpid, other.corpid)
				&& Objects.equals(email, other.email) && Objects.equals(id, other.id)
				&& Objects.equals(phonenumber, other.phonenumber) && Objects.equals(status, other.status);
	}

	public synchronized String getAddress3() {
		return Address3;
	}

	public synchronized void setAddress3(String address3) {
		Address3 = address3;
	}

	public synchronized String getStatus() {
		return status;
	}

	public synchronized void setStatus(String status) {
		this.status = status;
	}

	public SBI_RTGS_MANAGER_Archive() {

	}

	public SBI_RTGS_MANAGER_Archive(String id, String corpid, String accountnumber, String IFSCCode, String IFSCReceiver,
			String Bankbranch, String email, String phonenumber, String Address1, String Address2, String Address3,
			String status) {
		this.id = id;
		this.corpid = corpid;
		this.accountnumber = accountnumber;
		this.IFSCCode = IFSCCode;
		this.IFSCReceiver = IFSCReceiver;
		this.Bankbranch = Bankbranch;
		this.email = email;
		this.phonenumber = phonenumber;
		this.Address1 = Address1;
		this.Address2 = Address2;
		this.Address3 = Address3;
		this.status = status;
	}
}
