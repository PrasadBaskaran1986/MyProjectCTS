package com.javatpoint.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javatpoint.model.SBIRTGSMANAGER;



public interface SBIRTGSMANAGERRepository extends JpaRepository<SBIRTGSMANAGER, String> {
	List<SBIRTGSMANAGER> findByPublished(boolean published);
	List<SBIRTGSMANAGER> findByTitleContaining(String title);
}
