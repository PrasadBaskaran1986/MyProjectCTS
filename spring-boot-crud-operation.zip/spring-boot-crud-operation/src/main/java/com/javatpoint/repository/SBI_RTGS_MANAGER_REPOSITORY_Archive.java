package com.javatpoint.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.javatpoint.model.SBI_RTGS_MANAGER_Archive;



public interface SBI_RTGS_MANAGER_REPOSITORY_Archive extends JpaRepository<SBI_RTGS_MANAGER_Archive, String> {
//	List<SBI_RTGS_MANAGER> findByPublished(String id);
//	List<SBI_RTGS_MANAGER> findByTitleContaining(String id);
}
